 ### Complete the following exercises in Python.
These exercises will help understand the Code Modeling discussed during Week 1 and Week 2

-   **find_max**(self, a_list):Return the maximum element from a nonempty Python list.
-   **search_two_lists**(self, list1, list2, value):Search 2 Python lists to see if the value exist in either one
-   **prefix_average**(self, a_list):Return list such that, for all j, A[j] equals average of S[0], ..., S[j].

-   **linear_search**(self, my_list, target):Find target value, return true if exists.
-   **swap_positions**(self, list1, pos1, pos2):swap the positions of elements in a given python list1

-   **unique**(self, data):We are given a single sequence S with n elements, we are to find out whether all elements of that collection are distinct from each other.Return True of there are no duplicate elements in sequence named as data.
-   **is_valid_subsequence**(self, array, sequence): We are given 2 Python lists that contains integers. Complete this function that determines whether the second list is a subsequence of the first one.
- A subsequence of a list is a set of numbers that are not necessarily adjacent in the list, but they are in the same order as they appear in the list. 
#### Example: 
  * Our list is : [100, 200, 300, 400]
  * [100,300,400] is a subsequence of this list 
  * [200,400] is also a subsequence of this list
      


Go to solution.py on File Tree to complete these methods.
Follow the order presented above, as we discuss best practices.
Click **Submit  AND MARK COMPLETE** when finished.

You are also given a starter package under your File Tree here in Codio.
Name of your starter package is **CC1.zip.**
Working locally is entirely optional. But it really helps to use PyCharm's debugger so we strongly encourage that you download the starter package to your local drive.
After download, please extract it ( uncompress/unzip). Then open this directory through PyCharm.
In the starter package you will find the following files:
1. solution.py   ( this is the file you complete the code)
1. tests.py      (this is the file that contains unit tests and tests each function that you write on solution.py)
1. specs.md      (this is your specifications document)

When you complete your work on solution.py. 
You can:
1.   Simply find the solution.py under Codio, file tree, select all that incomplete code and  delete its content, refresh your page few times so solution.py is blank. Copy everything from your local solution.py to Codio solution.py
1.  Or rename solution.py under Codio File tree to solution_old.py and upload your local solution.py to here on Codio, delete solution_old.py.

And then don't forget to click the **Submit** button to Submit your work and scroll all the way down to **MARK YOUR WORK COMPLETE**

