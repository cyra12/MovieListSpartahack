class RunTimeExercises:

    def find_max(self, a_list):
        """Return the maximum element from a nonempty Python list."""
        """this was project 0..."""
        pass

    def search_two_lists(self, list1, list2, value):
        """Search 2 Python lists to see if the value exist in either one"""
        pass

    def prefix_average(self, a_list):
        """Return list such that, for all j, A[j] equals average of S[0], ..., S[j]."""
        pass

    def linear_search(self, my_list, target):
        """Find target value, return true if exists."""
        pass

    def swap_positions(self, list1, pos1, pos2):
        """Swap the positions of elements in a given python list1"""
        pass

    def unique(self, data):
        """Find out whether all elements of that collection are distinct
    from each other.
    Return True of there are no duplicate elements in sequence named as data"""
        pass

    def is_valid_subsequence(self, array, sequence):
        """Determine whether the second list named as sequence is a subsequence of the first one named as array"""

        pass
